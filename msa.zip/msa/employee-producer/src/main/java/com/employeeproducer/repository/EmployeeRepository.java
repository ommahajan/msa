package com.employeeproducer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employeeproducer.model.EmployeeFromDB;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeFromDB, String>{

	
}
