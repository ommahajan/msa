package com.zullservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZullServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
