package com.zullservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

import com.zullservice.filter.ErrorFilter;
import com.zullservice.filter.PostFilter;
import com.zullservice.filter.PreFilter;
import com.zullservice.filter.RouteFilter;

@SpringBootApplication
@EnableZuulProxy
public class ZullServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZullServiceApplication.class, args);
	}

	@Bean
	public PreFilter preFilter() {
		return new PreFilter();
	}

	@Bean
	public PostFilter postFilter() {
		return new PostFilter();
	}

	@Bean
	public ErrorFilter errorFilter() {
		return new ErrorFilter();
	}

	@Bean
	public RouteFilter routeFilter() {
		return new RouteFilter();
	}
	
}
